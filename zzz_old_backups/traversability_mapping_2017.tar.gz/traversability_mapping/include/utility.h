#ifndef _UTILITY_TM_H_
#define _UTILITY_TM_H_

#include <ros/ros.h>

#include <std_msgs/Header.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/LaserScan.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/OccupancyGrid.h>
#include <geometry_msgs/PoseArray.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <visualization_msgs/Marker.h>
#include <interactive_markers/interactive_marker_server.h>

#include <nav_core/base_global_planner.h>
#include <costmap_2d/costmap_2d_ros.h>

#include <cv_bridge/cv_bridge.h>
#include <image_transport/image_transport.h>

#include <pcl/point_types.h>
#include <pcl_ros/point_cloud.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/range_image/range_image.h>
#include <pcl/filters/filter.h>
#include <pcl/filters/voxel_grid.h>

#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_datatypes.h>
#include <pcl_ros/transforms.h>

#include <vector>
#include <cmath>
#include <algorithm>
#include <queue>
#include <iostream>
#include <fstream>
#include <ctime>
#include <cfloat>
#include <iterator>
#include <sstream>
#include <string>
// #include <array> // c++11
// #include <thread> // c++11
// #include <mutex> // c++11

#include "dubins.h"
#include "kdtree.h"
#include "cubic_spline_interpolator.h"

// #include <gsl/gsl_fit.h>

using namespace std;



typedef pcl::PointXYZI  PointType;
typedef struct kdtree kdtree_t;
typedef struct kdres kdres_t;

/*
    Velodyne Sensor Configuration: Velodyne Puck
    */
extern const int N_SCAN = 16;
extern const int Horizon_SCAN = 1800;

extern const float max_range = 100;
extern const float min_range = 0.4;

extern const float ang_res_x = 0.2;
extern const float ang_res_y = 2.0;

extern const float ang_start_x = 270;
extern const float ang_start_y = 15;

extern const float factor = 1.0f / (max_range - min_range);
extern const float offset = -min_range;

extern const float sensorHeight = 0.5;

/*
    Mapping Configuration
    */
extern const bool multiLayerMappingFlag = false;

extern const float mapResolution = 0.1; // map resolution
extern const float mapCubeLength = 10.0; // the length of a sub-map (meters)
extern const int mapCubeArrayLength = mapCubeLength / mapResolution; // the grid dimension of a sub-map (mapCubeLength / mapResolution)
extern const int mapArrayLength = 200; // the sub-map dimension of global map
extern const int rootCubeIndex = mapArrayLength / 2; // by default, robot is at the center of global map at the beginning

extern const float heightThreshold = 1.0; // if the height difference between two points is larger than this, add a new cell to the grid
/*
    Mapping Publish Configuration
    */
extern const int localMapLength = 20;// / (0.1 / mapResolution); // length of the local occupancy grid map (meter)
extern const int localMapArrayLength = localMapLength / mapResolution;
extern const int globalMapInflation = 3; // 
/*
    Filter Settings
    */
extern const int NUM_ROWS = N_SCAN / 2 + 1; // rings that are processed in range image filter
extern const float RANGE_LIMIT = 20; // point that has range within this value to robot is sent to mapping
extern const float ANGLE_LIMIT = 20; // slope angle threshold           >>>>>>>>----------------------------<<<<<<<<
extern const int PUB_ROWS = NUM_ROWS - 1; // ring number that will be sent to mapping process (default: NUM_ROWS - 1)
                                            // if PUB_ROWS = NUM_ROWS, the ring that is ablove horizon is also published
                                            // this ring is considered as obstacle (similar to Hokuyo scan)
extern const int rangeCompareNeighborNum = 3;
/*
    Publish Settings
    */
extern const int pubSkipCountRangeimage = 1; // publish point cloud after receiving n images (time = 0.1*n s)
extern const int pubSkipCountMapping = 10; // publish period = pubSkipCountRangeimage / 10 * pubSkipCountMapping
extern const double pubSkipCountFullCloudTime = 5;
extern const float CLOUD_INTERVAL = 2; // publish a point after skipping x number of point. should be even number, i.e. 1, 2, 4.


/*
    Planner Settings
    */
extern const int NUM_COSTS = 3;
extern const int tmp[] = {2};
extern const std::vector<int> costHierarchy(tmp, tmp+sizeof(tmp)/sizeof(int));// c++11 initialization: costHierarchy{0, 1, 2}
extern const float terrainRoughnessThreshold = 0.1;
// PRM Planner Settings
extern const double neighborSampleRadius = mapResolution * 10; // 7.5 or 10
extern const double neighborConnectHeight = heightThreshold;//mapResolution * 3;
extern const double neighborConnectRadius = mapResolution * 50; // 15 or 20
extern const double neighborSearchRadius = localMapLength / 2;
// RRT* Planner Settings
extern const double turningRadius = 0.2; // turning radius of Dubins vehicle
extern const double runTime = 0.1; // run time of rrt* planner (seconds)
extern const double goalBias = 0.05; // pobability of sampling goal state 0~1
extern const double goalRegionRadius = 1.0;
extern const bool switchRootFlag = true;

/*
    Occupancy Grid Map Configuration
    occupancy map probability settings
    */
extern const float p_occupied_when_laser = 0.9;
extern const float p_occupied_when_no_laser = 0.3;
extern const float large_log_odds = 100;
extern const float max_log_odds_for_belief = 20;

/*
    Full Point Cloud Map Settings
    */
extern const bool recordFullPointCloud = false;
extern const float fullCloudResolution = 0.2;
extern const int laserCloudCubeWidth = 10; // a cube width in meters
extern const int laserCloudCubeDepth = 10; // a cube height in meters
extern const int laserCloudCubeHeight = 10; // a cube length in meters
extern const int laserArrayCloudWidth = 100; // number of cubes along width direction in full point cloud map 
extern const int laserArrayCloudDepth = 100; // number of cubes along height direction in full point cloud map 
extern const int laserArrayCloudHeight = 10; // number of cubes along length direction in full point cloud map
extern const int laserReceiveSkipNum = 0;


/*
    Cell Definition:
    a cell is a member of a grid in a sub-map
    a grid can have several cells in it. 
    a cell represent one height information
    */
struct mapCell{
    float log_odds;
    int occupancy;
    float height;
    int times;
    mapCell(){
        log_odds = 0.5; //
        occupancy = -1; // initialized as unkown
        height = -FLT_MAX;
        times = 0;
    }
};

/*
    Grid Definition:
    cellList is a grid of childMap. We call it "cells".
    */
struct cellList{ 
    std::vector<mapCell> cells;
};

/*
    Sub-map Definition:
    childMap is a small square. We call it "subMap". 
    It composes the whole map
    */
struct childMap{
    vector<vector<cellList > > subMap;
    int subInd; //sub-map's index in 1d mapArray
    int indX; // sub-map's x index in 2d array mapArrayInd
    int indY; // sub-map's y index in 2d array mapArrayInd
    float originX; // sub-map's x root coordinate
    float originY; // sub-map's y root coordinate
    childMap(){
        subMap.resize(mapCubeArrayLength);
        for (int i = 0; i < mapCubeArrayLength; ++i)
            subMap[i].resize(mapCubeArrayLength);
    }
};

/*
    This struct is used to send map from mapping package to prm package
    */
struct GRID{
    int cubeX;
    int cubeY;
    int gridX;
    int gridY;
    float height;
};

/*
    Robot State Defination
    */
struct state_t;
struct neighbor_t;

struct state_t{
    double x[3]; //  1 - x, 2 - y, 3 - z
    float theta;
    // # Cost types
    // # 0. obstacle cost
    // # 1. elevation cost
    // # 2. distance cost
    // # 3. --
    // # 4. --
    // # 5. --
    float costsToRoot[NUM_COSTS];
    float costsToParent[NUM_COSTS]; // used in RRT*
    float costsToGo[NUM_COSTS];

    state_t* parentState; // parent for this state in PRM and RRT*
    vector<neighbor_t> neighborList; // PRM adjencency list with edge costs
    vector<state_t*> childList; // RRT*

    // default initialization
    state_t(){
        parentState = NULL;
        for (int i = 0; i < NUM_COSTS; ++i){
            costsToRoot[i] = FLT_MAX;
            costsToParent[i] = FLT_MAX;
            costsToGo[i] = FLT_MAX;
        }
    }
    // use a state input to initialize new state
    
    state_t(state_t* stateIn){
        // pose initialization
        for (int i = 0; i < 3; ++i)
            x[i] = stateIn->x[i];
        theta = stateIn->theta;
        // regular initialization
        parentState = NULL;
        for (int i = 0; i < NUM_COSTS; ++i){
            costsToRoot[i] = FLT_MAX;
            costsToParent[i] = stateIn->costsToParent[i];
        }
    }
};


struct neighbor_t{
    state_t* neighbor;
    float edgeCosts[NUM_COSTS]; // the cost from this state to neighbor
    neighbor_t(){
        neighbor = NULL;
        for (int i = 0; i < NUM_COSTS; ++i)
            edgeCosts[i] = FLT_MAX;
    }
};









////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////      Some Functions    ////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
state_t *compareState;
bool isStateExsiting(neighbor_t neighborIn){
    return neighborIn.neighbor == compareState ? true : false;
}



#endif
