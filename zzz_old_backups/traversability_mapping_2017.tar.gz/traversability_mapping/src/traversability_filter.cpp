#include "utility.h"

class TraversabilityFilter{
private:

    ros::NodeHandle nh;
    // point cloud to range image
    ros::Subscriber subCloud;
    pcl::PointCloud<PointType>::Ptr laserCloudIn;

    tf::TransformListener listener;
    tf::StampedTransform transform;

    ros::Publisher pubCloud;
    ros::Publisher pubLaserScan;

    int pubCount;

    pcl::PointCloud<PointType>::Ptr laserCloudOut;
    pcl::PointCloud<PointType>::Ptr laserCloudMatrix[NUM_ROWS];
    pcl::PointCloud<PointType>::Ptr laserCloudMatrix2[NUM_ROWS];

    sensor_msgs::LaserScan laserScan;
    float ringGroundRange[8];

    cv::Mat rangeMatrix;

public:
    TraversabilityFilter():
        nh("~"),
        pubCount(0){

        subCloud = nh.subscribe<sensor_msgs::PointCloud2>("/velodyne_points", 1, &TraversabilityFilter::cloudHandler, this);
        pubCloud = nh.advertise<sensor_msgs::PointCloud2> ("/filtered_pointcloud", 100);
        pubLaserScan = nh.advertise<sensor_msgs::LaserScan> ("/pointcloud_2_laserscan", 1);  

        allocateMemory();

        pointcloud2laserscanInitialization();
    }

    void allocateMemory(){

        laserCloudIn.reset(new pcl::PointCloud<PointType>());
        laserCloudOut.reset(new pcl::PointCloud<PointType>());

        for (int i = 0; i < NUM_ROWS; ++i){
            laserCloudMatrix[i].reset(new pcl::PointCloud<PointType>());
            laserCloudMatrix2[i].reset(new pcl::PointCloud<PointType>());
        }

        PointType thisPoint;
        for (int i = 0; i < NUM_ROWS; ++i)
            for (int j = 0; j < Horizon_SCAN; ++j)
                laserCloudMatrix[i]->push_back(thisPoint);
    }

    ~TraversabilityFilter(){}
    /*
        cloudHadler:
        Receive velodyne point cloud and convert it to range image
        */
    void cloudHandler(const sensor_msgs::PointCloud2ConstPtr& laserCloudMsg){
        // 1. Convert ros message to pcl point cloud
        laserCloudIn->clear();
        pcl::fromROSMsg(*laserCloudMsg, *laserCloudIn);
        std::vector<int> indices;
        pcl::removeNaNFromPointCloud(*laserCloudIn,*laserCloudIn, indices);
        // 2. Point cloud to range image (full resolution)
        rangeMatrix = cv::Mat::zeros(N_SCAN, Horizon_SCAN, CV_32F);

        for (int i = 0; i < NUM_ROWS; ++i){
            for (int j = 0; j < Horizon_SCAN; ++j){
                laserCloudMatrix[i]->points[j].intensity = -1;
                // rangeMatrix.at<float>(i, j) = FLT_MAX;
            }
        }

        PointType thisPoint;
        float verticalAngle, horizonAngle, range;
        int rowIdn, columnIdn;

        for (int i = 0; i < laserCloudIn->points.size(); ++i){

            thisPoint.x = laserCloudIn->points[i].x;
            thisPoint.y = laserCloudIn->points[i].y;
            thisPoint.z = laserCloudIn->points[i].z;

            // 2.1 Find the row and column index in the iamge for this point
            verticalAngle = atan2(thisPoint.z, sqrt(thisPoint.x * thisPoint.x + thisPoint.y * thisPoint.y)) * 180 / M_PI;
            rowIdn = (verticalAngle + 15.1) / ang_res_y;

            if (rowIdn < 0 || rowIdn >= NUM_ROWS)
                continue;

            horizonAngle = atan2(thisPoint.x, thisPoint.y) * 180 / M_PI;
            if (horizonAngle <= -90)
                columnIdn = -int(horizonAngle / ang_res_x) - 450; 
            else if (horizonAngle >= 0)
                columnIdn =  -int(horizonAngle / ang_res_x) + 1350;
            else
                columnIdn =  1350 - int(horizonAngle / ang_res_x);

            // 2.2 Calculate range
            range = sqrt(thisPoint.x * thisPoint.x + thisPoint.y * thisPoint.y + thisPoint.z * thisPoint.z);

            // because of noise, some columns may not be updated forever
            if (rangeMatrix.at<float>(rowIdn, columnIdn) != FLT_MAX)
                columnIdn = columnIdn > 0 ? columnIdn - 1: columnIdn;

            rangeMatrix.at<float>(rowIdn, columnIdn) = range;
            laserCloudMatrix[rowIdn]->points[columnIdn] = thisPoint;
        }

        // 3. Process range image
        imageProcess();

        // 4. Publish Point Cloud to 2D Laser Scan
        publishLaserScanFusion();

        return;
    }

    /*
        imageHandler:
        Process the range image from cloudHandler
        */
    void imageProcess(){
        
        // 1. Transform point
        // Listen to the TF transform and prepare for point cloud transformation
        try{listener.lookupTransform("map","base_link", ros::Time(0), transform); } 
        catch (tf::TransformException ex){ /*ROS_ERROR("Transfrom Failure.");*/ return; }

        for (int i = 0; i < NUM_ROWS; ++i){
            laserCloudMatrix[i]->header.frame_id = "base_link";
            pcl_ros::transformPointCloud("map", *laserCloudMatrix[i], *laserCloudMatrix2[i], listener);
            pcl::PointCloud<PointType>::Ptr laserCloudTemp = laserCloudMatrix2[i];
            laserCloudMatrix2[i] = laserCloudMatrix[i];
            laserCloudMatrix[i] = laserCloudTemp;
        }
        // 2. Filter
        curbFilter();
        slopeFilter();
        
        // 3. Publish
        publishCloud();
    }



    void curbFilter(){
        // 1. Range filter
        float diff[Horizon_SCAN - 1];
        bool breakFlag;
        for (int i = 0; i < NUM_ROWS - 1; ++i){
            // calculate range difference
            for (int j = 0; j < Horizon_SCAN - 1; ++j)
                diff[j] = rangeMatrix.at<float>(i, j) - rangeMatrix.at<float>(i, j+1);

            for (int j = rangeCompareNeighborNum; j < Horizon_SCAN - rangeCompareNeighborNum; ++j){
                breakFlag = false;
                // point is two far away, skip comparison since it can be inaccurate
                if (rangeMatrix.at<float>(i, j) > RANGE_LIMIT)
                    continue;
                // make sure all points have valid range info
                for (int k = -rangeCompareNeighborNum; k <= rangeCompareNeighborNum; ++k)
                    if (rangeMatrix.at<float>(i, j+k) == 0){
                        breakFlag = true;
                        break;
                    }
                if (breakFlag == true) continue;
                // range difference should be monotonically increasing or decresing
                for (int k = -rangeCompareNeighborNum; k < rangeCompareNeighborNum-1; ++k)
                    if (diff[j+k] * diff[j+k+1] <= 0){
                        breakFlag = true;
                        break;
                    }
                if (breakFlag == true) continue;
                // the range difference between the start and end point of neighbor points is smaller than a threashold, then continue
                if (abs(rangeMatrix.at<float>(i, j-rangeCompareNeighborNum) - rangeMatrix.at<float>(i, j+rangeCompareNeighborNum)) /rangeMatrix.at<float>(i, j) < 0.03)
                    continue;
                // if "continue" is not used at this point, it is very likely to be an obstacle point
                laserCloudMatrix[i]->points[j].intensity = 100;
            }
        }
    }

    void slopeFilter(){
        // 2. Slope filter
        float diffX, diffY, diffZ, angle;
        for (int j = 0; j < Horizon_SCAN; ++j){
            for (int i = 0; i < NUM_ROWS - 1; ++i){
                // 2.1 point without range value cannot be compared
                if (laserCloudMatrix[i]->points[j].intensity == -1 || laserCloudMatrix[i+1]->points[j].intensity == -1){
                    laserCloudMatrix[i]->points[j].intensity = -1;
                    continue;
                }
                // 2.2 Point that has been verified by range filter
                if (laserCloudMatrix[i]->points[j].intensity == 100)
                    continue;
                // 2.3  Two range filters here
                //      if a point's range is larger than 8 or 9 th ring point's range
                //      if a point's range is larger than the upper point's range
                //      then this point is very likely on obstacle. i.e. a point under the car or on a pole
                if (  ((rangeMatrix.at<float>(8, j) != 0 && rangeMatrix.at<float>(i, j) > rangeMatrix.at<float>(8, j)) // 9th ring (the first ring above horizon)
                    || (rangeMatrix.at<float>(7, j) != 0 && rangeMatrix.at<float>(i, j) > rangeMatrix.at<float>(7, j))) // 8th ring (the first ring below horizon)
                    || (rangeMatrix.at<float>(i, j) > rangeMatrix.at<float>(i+1, j)) ){
                    laserCloudMatrix[i]->points[j].intensity = 100;
                    continue;
                }
                // 2.4 Calculate slope angle
                diffX = laserCloudMatrix[i+1]->points[j].x - laserCloudMatrix[i]->points[j].x;
                diffY = laserCloudMatrix[i+1]->points[j].y - laserCloudMatrix[i]->points[j].y;
                diffZ = laserCloudMatrix[i+1]->points[j].z - laserCloudMatrix[i]->points[j].z;

                angle = atan2(diffZ, sqrt(diffX*diffX + diffY*diffY) ) * 180 / M_PI;
                // 2.5 Slope angle is larger than threashold, mark as obstacle point
                if (angle < -ANGLE_LIMIT || angle > ANGLE_LIMIT){
                    laserCloudMatrix[i]->points[j].intensity = 100;
                    continue;
                }
            }
        }
    }

    void publishCloud(){
        // 1. Save point to laserCloud from laserCloudMatrix       
        for (int j = 1; j < Horizon_SCAN - 1; ++j){
            for (int i = 0; i < PUB_ROWS; ++i){
                // 1.1 point that has no range information or too far away is discarded
                if (laserCloudMatrix[i]->points[j].intensity == -1 ||
                    rangeMatrix.at<float>(i, j) >= RANGE_LIMIT)
                    continue;
                // 1.2 filter single obstacle point
                if (laserCloudMatrix[i]->points[j].intensity == 100 &&
                    laserCloudMatrix[i]->points[j-1].intensity == 0 &&
                    laserCloudMatrix[i]->points[j+1].intensity == 0)
                    continue;

                laserCloudOut->push_back(laserCloudMatrix[i]->points[j]);

                // if (laserCloudMatrix[i]->points[j].intensity == 100)
                //     break;
            }
        }

        // 2. Publish message
        sensor_msgs::PointCloud2 laserCloudFull;
        pcl::toROSMsg(*laserCloudOut, laserCloudFull);

        laserCloudFull.header.stamp = ros::Time::now(); // the laser cloud time should be older since odometry is received after velodyne_points
        laserCloudFull.header.frame_id = "map";

        pubCloud.publish(laserCloudFull);
        // 3. Clear cloud
        laserCloudOut->clear();
        for (int i = 0; i < NUM_ROWS; ++i){
            // laserCloudMatrix[i]->clear();
            laserCloudMatrix2[i]->clear();
        }
    }

    void pointcloud2laserscanInitialization(){
        laserScan.header.frame_id = "base_link"; // assume laser has the same frame as the robot

        laserScan.angle_min = -M_PI;
        laserScan.angle_max =  M_PI;
        laserScan.angle_increment = ang_res_x / 180 * M_PI;
        laserScan.time_increment = 0;

        laserScan.scan_time = 0.1; // 10Hz
        laserScan.range_min = 0.4;
        laserScan.range_max = 80;//localMapLength / 2;

        int range_size = std::ceil((laserScan.angle_max - laserScan.angle_min) / laserScan.angle_increment);
        laserScan.ranges.assign(range_size, laserScan.range_max + 1.0);

        for (int i = 0; i < 8; ++i){
            ringGroundRange[i] =  sensorHeight / std::sin((15.1 - i * ang_res_y) / 180 * M_PI);
        }
    }

    void publishLaserScanFusion(){

        // initliaze range values
        laserScan.header.stamp = ros::Time::now();
        std::fill(laserScan.ranges.begin(), laserScan.ranges.end(), laserScan.range_max + 1.0);
         // update range array
        for (int i = 0; i < Horizon_SCAN; ++i){
            if (rangeMatrix.at<float>(8, i) == 0 || rangeMatrix.at<float>(8, i) > laserScan.range_max)
                continue;
            laserScan.ranges[i] = rangeMatrix.at<float>(8, i);
            for (int row = 2; row < 8; ++row){
                if (rangeMatrix.at<float>(row, i) == 0)
                    continue;
                if (rangeMatrix.at<float>(row, i) <= 0.5 * ringGroundRange[row])
                    laserScan.ranges[i] = std::min(laserScan.ranges[i], 
                                                        float(rangeMatrix.at<float>(row, i) * std::cos((15.1 - row * ang_res_y) / 180 * M_PI)));
            }
        }
        pubLaserScan.publish(laserScan);
    }
};




int main(int argc, char** argv){

    ros::init(argc, argv, "traversability_mapping");
    
    TraversabilityFilter TFilter;

    ROS_INFO("\033[1;32m---->\033[0m Traversability Point Cloud Filter Started.");

    ros::spin();
    return 0;
}





