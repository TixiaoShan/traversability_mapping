#include "utility.h"

#include "elevation_msgs/OccupancyElevation.h"

class TraversabilityMapping{
private:

    ros::NodeHandle nh;

    tf::TransformListener listener;
    tf::StampedTransform transform;

    ros::Subscriber subFilteredGroundCloud;
    
    ros::Publisher pubOccupancyMap;
    ros::Publisher pubOccupancyMapLocal;
    ros::Publisher pubOccupancyMapLocalHeight;
    ros::Publisher pubElevationCloud;

    pcl::PointCloud<PointType>::Ptr laserCloud; // save input filtered laser cloud for mapping
    pcl::PointCloud<PointType>::Ptr laserCloudArray[mapArrayLength][mapArrayLength];
    pcl::PointCloud<PointType>::Ptr laserCloudElevation; // a cloud for publishing elevation map

    
    nav_msgs::OccupancyGrid occupancyMap2D; // global occupancy grid map
    elevation_msgs::OccupancyElevation occupancyMap2DHeight; // customized message that includes occupancy map and elevation info

    int pubCount;
    
    int mapArrayCount;
    int **mapArrayInd; // it saves the index of this submap in vector mapArray
    int **mapArrayUpdate; // it saves the cube that is updated during this scan. set to 0 when the callback ends
    vector<childMap> mapArray;

    int minXCubeInd, maxXCubeInd, minYCubeInd, maxYCubeInd;
    int inflatedMinXCubeInd, inflatedMaxXCubeInd, inflatedMinYCubeInd, inflatedMaxYCubeInd;

    PointType robotPoint;

public:
    TraversabilityMapping():
        nh("~"),
        pubCount(0),
        mapArrayCount(0),
        minXCubeInd(mapArrayLength),maxXCubeInd(0),minYCubeInd(mapArrayLength), maxYCubeInd(0),
        inflatedMinXCubeInd(0), inflatedMaxXCubeInd(0), inflatedMinYCubeInd(0), inflatedMaxYCubeInd(0)
        {

        subFilteredGroundCloud = nh.subscribe<sensor_msgs::PointCloud2>("/filtered_pointcloud", 100, &TraversabilityMapping::cloudHandler, this);

        pubOccupancyMap = nh.advertise<nav_msgs::OccupancyGrid> ("/occupancy_map_global", 1);
        pubOccupancyMapLocal = nh.advertise<nav_msgs::OccupancyGrid> ("/occupancy_map_local", 1);
        pubOccupancyMapLocalHeight = nh.advertise<elevation_msgs::OccupancyElevation> ("/occupancy_map_local_height", 1);

        pubElevationCloud = nh.advertise<sensor_msgs::PointCloud2> ("/elevation_pointcloud", 1);  

        allocateMemory(); 
    }

    ~TraversabilityMapping(){}

    

    void allocateMemory(){
        laserCloud.reset(new pcl::PointCloud<PointType>());
        laserCloudElevation.reset(new pcl::PointCloud<PointType>());
        
        // initialize array for cube map
        mapArrayInd = new int*[mapArrayLength];
        for (int i = 0; i < mapArrayLength; ++i)
            mapArrayInd[i] = new int[mapArrayLength];
        // initialize mapArrayUpdate matrix
        mapArrayUpdate = new int*[mapArrayLength];
        for (int i = 0; i < mapArrayLength; ++i)
            mapArrayUpdate[i] = new int[mapArrayLength];
        
        // initialize elements
        for (int i = 0; i < mapArrayLength; ++i)
            for (int j = 0; j < mapArrayLength; ++j){
                mapArrayInd[i][j] = -1;
                mapArrayUpdate[i][j] = 0;
                laserCloudArray[i][j].reset(new pcl::PointCloud<PointType>());
            }

        initializeLocalOccupancyMap();
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////// Mapping /////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void cloudHandler(const sensor_msgs::PointCloud2ConstPtr& laserCloudMsg){

        laserCloud->clear();
        pcl::fromROSMsg(*laserCloudMsg, *laserCloud);
        std::vector<int> indices;
        pcl::removeNaNFromPointCloud(*laserCloud,*laserCloud, indices);

        PointType point;
        int cloudSize = laserCloud->points.size();

        for (int i = 0; i < cloudSize; ++i){
            point.x = laserCloud->points[i].x;
            point.y = laserCloud->points[i].y;
            point.z = laserCloud->points[i].z - 0.1; // make map a bitlower to visualize more clearly
            point.intensity = laserCloud->points[i].intensity; // intensity represents occupancy
            updateElevationMap(&point);
        }
        
        pubCount++;
        if (pubCount >= pubSkipCountMapping){
            publishGlobalOccupancyGridMap();
            publishLocalOccupancyGridMap();
            publishElevationPointCloud();
            pubCount = 0;
        }
    }

    bool updateElevationMap(PointType *point){

        // 1. Calculate the cube index that this point belongs to. (Array dimension: mapArrayLength * mapArrayLength)
        int cubeX, cubeY;
        getPointCubeIndex(&cubeX, &cubeY, point);

        // 2.1. Decide whether a point is out of pre-allocated map
        if (cubeX >= 0 && cubeX < mapArrayLength && 
            cubeY >= 0 && cubeY < mapArrayLength){
            // 2.1.1 Point is in the boundary, but this sub-map is not allocated before
            //     Allocate new memory for this sub-map and save it to mapArray
            if (mapArrayInd[cubeX][cubeY] == -1){
                childMap thisChildMap;
                thisChildMap.subInd = mapArrayCount;
                thisChildMap.indX = cubeX;
                thisChildMap.indY = cubeY;
                thisChildMap.originX = (cubeX - rootCubeIndex) * mapCubeLength - mapCubeLength/2.0;;
                thisChildMap.originY = (cubeY - rootCubeIndex) * mapCubeLength - mapCubeLength/2.0;;
                mapArray.push_back(thisChildMap);
                mapArrayInd[cubeX][cubeY] = mapArrayCount;
                ++mapArrayCount;
                // update the minimum and maximum index for the sub-map
                minXCubeInd = std::min(minXCubeInd, cubeX);
                maxXCubeInd = std::max(maxXCubeInd, cubeX);
                minYCubeInd = std::min(minYCubeInd, cubeY);
                maxYCubeInd = std::max(maxYCubeInd, cubeY);
                // update the minimum and maximum index for the sub-map
                inflatedMinXCubeInd = std::max(minXCubeInd - globalMapInflation, 0);
                inflatedMaxXCubeInd = std::min(maxXCubeInd + globalMapInflation, mapArrayLength);
                inflatedMinYCubeInd = std::max(minYCubeInd - globalMapInflation, 0);
                inflatedMaxYCubeInd = std::min(maxYCubeInd + globalMapInflation, mapArrayLength);
            }

        }else{
            // 2.1.2 Point is out of pre-allocated boundary, report error (increase map size)
            ROS_WARN("Point cloud is out of elevation map boundary.");
            return false;
        }

        // 3. Save this point to this sub-map
        // 3.0 The msub-map that this point belongs to is updated. Mark for future publish
        int thisSubMapInd = mapArrayInd[cubeX][cubeY];
        mapArrayUpdate[cubeX][cubeY] = 1;

        // 2.2 Find the index for this point in this sub-map (grid index)
        int gridX = (int)((point->x - mapArray[thisSubMapInd].originX) / mapResolution);
        int gridY = (int)((point->y - mapArray[thisSubMapInd].originY) / mapResolution);

        if (gridX < 0 || gridY < 0 || gridX >=mapCubeArrayLength || gridY >= mapCubeArrayLength)
            return false;;

        // 3.1. the cell (in sub-map) that this point belongs to is empty
        if (mapArray[thisSubMapInd].subMap[gridX][gridY].cells.size() == 0){
            addNewCelltoGrid(thisSubMapInd, gridX, gridY, point);
            return true;;
        }
        // 3.2. the cell (in sub-map) that this point belongs to is not empty
        int closestInd;
        float p;  // Probability of being occupied knowing current measurement.
        if (point->intensity == 100)
            p = p_occupied_when_laser;
        else
            p = p_occupied_when_no_laser;
        // 3.2.1 Single layer mapping, the operated cell index is 0
        if (multiLayerMappingFlag == false){
            closestInd = 0;
        }
        // 3.2.2 Multi layer mapping, find the operated cell index
        else{
            float minDiff = FLT_MAX, diff;
            int iteratorCount = 0;
            // 3.2.2.1 Calculate the minimum height difference between this point and other saved heights
            for (vector<mapCell>::iterator iter = mapArray[thisSubMapInd].subMap[gridX][gridY].cells.begin(); iter != mapArray[thisSubMapInd].subMap[gridX][gridY].cells.end(); iter++) {
                mapCell thisCell = *iter;
                diff = abs(thisCell.height - point->z);
                if (diff < minDiff){
                    minDiff = diff;
                    closestInd = iteratorCount;
                }
                ++iteratorCount;
            }
            // 3.2.2.2 minimal height diffrence is larger than threashold, then add new height cell
            if (minDiff > heightThreshold){
                addNewCelltoGrid(thisSubMapInd, gridX, gridY, point);
                return true;
            }
            
        }
        updateGridOccupancy(thisSubMapInd, gridX, gridY, closestInd, p);

        updateGridHeight(thisSubMapInd, gridX, gridY, closestInd, point);

        return true;
    }

    void getPointCubeIndex(int *cubeX, int *cubeY, PointType *point){
        *cubeX = int((point->x + mapCubeLength/2.0) / mapCubeLength) + rootCubeIndex;
        *cubeY = int((point->y + mapCubeLength/2.0) / mapCubeLength) + rootCubeIndex;

        if (point->x + mapCubeLength/2.0 < 0)  --*cubeX;
        if (point->y + mapCubeLength/2.0 < 0)  --*cubeY;
    }

    void addNewCelltoGrid(int thisSubMapInd, int gridX, int gridY, PointType *point){
        mapCell thisCell;
        thisCell.occupancy = (int)point->intensity;
        thisCell.height = point->z;
        mapArray[thisSubMapInd].subMap[gridX][gridY].cells.push_back(thisCell);
    }

    void updateGridOccupancy(int thisSubMapInd, int gridX, int gridY, int closestInd, float p){
        // 3.2.3 Update log_odds
        mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].log_odds += std::log(p / (1 - p));

        if (mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].log_odds < -large_log_odds)
            mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].log_odds = -large_log_odds;
        else if (mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].log_odds > large_log_odds)
            mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].log_odds = large_log_odds;
        // 3.2.3 Update occupancy
        if (mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].log_odds < -max_log_odds_for_belief)
            mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].occupancy = 0;
        else if (mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].log_odds > max_log_odds_for_belief)
            mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].occupancy = 100;
        else
            mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].occupancy = (int)
                (lround((1 - 1 / (1 + std::exp(mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].log_odds))) * 100));
    }

    void updateGridHeight(int thisSubMapInd, int gridX, int gridY, int closestInd, PointType *point){
        // 3.2.4 Update height
        mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].height = 
                    (point->z + mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].height * mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].times)
                    / (mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].times + 1);
        ++mapArray[thisSubMapInd].subMap[gridX][gridY].cells[closestInd].times;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////// Point Cloud /////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void publishElevationPointCloud(){

        if (pubElevationCloud.getNumSubscribers() == 0)
            return;

        PointType point;
        // 1. Clear the elevation cloud that is going to be published
        laserCloudElevation->clear();
        // 2. Loop through all the sub-maps that are updated during this update instance
        for (int i = 0; i < mapArrayLength; ++i){
            for (int j = 0; j < mapArrayLength; ++j){
                // 2.1 If a sub-map is updated
                if (mapArrayUpdate[i][j] == 1){
                    // 2.1.1 Clear the cloud array element since this element is updated
                    laserCloudArray[i][j]->clear();
                    int thisSubMapInd = mapArrayInd[i][j];
                    // 2.1.2 Loop through all grids in this sub-map
                    for (int cubeI = 0; cubeI < mapCubeArrayLength; cubeI = cubeI + CLOUD_INTERVAL){
                        for (int cubeJ = 0; cubeJ < mapCubeArrayLength; cubeJ = cubeJ + CLOUD_INTERVAL){
                            // 2.1.2.1 Cell is empty. No point exists in this grid.
                            if (mapArray[thisSubMapInd].subMap[cubeI][cubeJ].cells.size() == 0)
                                continue;
                            // 2.1.2.2 Covert all the height information to points
                            
                            for(int heightCount = 0; heightCount < mapArray[thisSubMapInd].subMap[cubeI][cubeJ].cells.size(); ++heightCount){
                                point.x = mapArray[thisSubMapInd].originX + cubeI * mapResolution;
                                point.y = mapArray[thisSubMapInd].originY + cubeJ * mapResolution;
                                point.z = mapArray[thisSubMapInd].subMap[cubeI][cubeJ].cells[heightCount].height;
                                if (mapArray[thisSubMapInd].subMap[cubeI][cubeJ].cells[heightCount].occupancy == 100)
                                    point.intensity = 100;
                                else
                                    point.intensity = 0;
                                laserCloudArray[i][j]->push_back(point);
                            }
                        }
                    }
                }
                // 2.2 Add point cloud element to the elevation cloud that is going to be published if element exists
                if (mapArrayInd[i][j] != -1)
                    *laserCloudElevation += *laserCloudArray[i][j];
            }
        }

        // 3. Initialize update array. So next update process we don't need to update cloud element that is not updated
        for (int i = 0; i < mapArrayLength; ++i)
            for (int j = 0; j < mapArrayLength; ++j)
                mapArrayUpdate[i][j] = 0;
        // 4. Publish elevation point cloud
        sensor_msgs::PointCloud2 laserCloudFull;
        pcl::toROSMsg(*laserCloudElevation, laserCloudFull);
        laserCloudFull.header.frame_id = "/map";
        laserCloudFull.header.stamp = ros::Time::now();
        pubElevationCloud.publish(laserCloudFull);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////// Occupancy Map (local) //////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    void initializeLocalOccupancyMap(){
        // initialization of customized map message
        occupancyMap2DHeight.header.frame_id = "map";
        occupancyMap2DHeight.occupancy.info.width = localMapArrayLength;
        occupancyMap2DHeight.occupancy.info.height = localMapArrayLength;
        occupancyMap2DHeight.occupancy.info.resolution = mapResolution;
        
        occupancyMap2DHeight.occupancy.info.origin.orientation.x = 0.0;
        occupancyMap2DHeight.occupancy.info.origin.orientation.y = 0.0;
        occupancyMap2DHeight.occupancy.info.origin.orientation.z = 0.0;
        occupancyMap2DHeight.occupancy.info.origin.orientation.w = 1.0;

        occupancyMap2DHeight.occupancy.data.resize(occupancyMap2DHeight.occupancy.info.width * occupancyMap2DHeight.occupancy.info.height);
        occupancyMap2DHeight.height.resize(occupancyMap2DHeight.occupancy.info.width * occupancyMap2DHeight.occupancy.info.height);
    }

    void publishLocalOccupancyGridMap(){

        // 1. Get robot index in the mapArray. These indexes will decide the position of local occupancy grid map.
        int robotCubeX, robotCubeY, robotGridX, robotGridY;
        getRobotPosition();
        if (getFullIndex(&robotPoint, &robotCubeX, &robotCubeY, &robotGridX, &robotGridY) == false)
            return;
        int localMapGridCenterX = localMapArrayLength / 2;
        int localMapGridCenterY = localMapArrayLength / 2;
        // 1.2 Calculate local occupancy grid map root position
        occupancyMap2DHeight.header.stamp = ros::Time::now();
        occupancyMap2DHeight.occupancy.header.stamp = ros::Time::now();
        occupancyMap2DHeight.occupancy.info.origin.position.x = robotPoint.x - localMapLength / 2;
        occupancyMap2DHeight.occupancy.info.origin.position.y = robotPoint.y - localMapLength / 2;
        occupancyMap2DHeight.occupancy.info.origin.position.z = robotPoint.z + 10; // add 10, just for visualization
        // 1.3 Initialize local occupancy grid map to unknown
        std::fill(occupancyMap2DHeight.occupancy.data.begin(), occupancyMap2DHeight.occupancy.data.end(), -1);
        // 1.4 Initialize 2D map height information
        std::fill(occupancyMap2DHeight.height.begin(), occupancyMap2DHeight.height.end(), -FLT_MAX);

        // 2. Create breadth-first search queue and save the start GRID -> robot's current position
        GRID thisGrid;
        thisGrid.cubeX = robotCubeX;
        thisGrid.cubeY = robotCubeY;
        thisGrid.gridX = robotGridX;
        thisGrid.gridY = robotGridY;
        thisGrid.height = robotPoint.z;

        // find height info that corresponds to the robot grid 
        float heightDiff = FLT_MAX;
        for (int heightCount = 0; heightCount < mapArray[mapArrayInd[thisGrid.cubeX][thisGrid.cubeY]].subMap[thisGrid.gridX][thisGrid.gridY].cells.size(); ++heightCount)
            if (abs(mapArray[mapArrayInd[thisGrid.cubeX][thisGrid.cubeY]].subMap[thisGrid.gridX][thisGrid.gridY].cells[heightCount].height - robotPoint.z) < heightDiff){
                heightDiff = abs(mapArray[mapArrayInd[thisGrid.cubeX][thisGrid.cubeY]].subMap[thisGrid.gridX][thisGrid.gridY].cells[heightCount].height - robotPoint.z);
                thisGrid.height = mapArray[mapArrayInd[thisGrid.cubeX][thisGrid.cubeY]].subMap[thisGrid.gridX][thisGrid.gridY].cells[heightCount].height;
            }

        std::queue<GRID> Queue;
        Queue.push(thisGrid);

        int thisSubMapInd, mapIndX,mapIndY, index; float thisHeight;
        int thisGridinMapX, thisGridinMapY, robotGridinMapX, robotGridinMapY;
        robotGridinMapX = robotCubeX * mapCubeArrayLength + robotGridX;
        robotGridinMapY = robotCubeY * mapCubeArrayLength + robotGridY;
        // 3. Breadth-first Search
        while(Queue.size() > 0 && ros::ok()){
            GRID fromGrid = Queue.front();
            Queue.pop();
            // 3.1 Loop through all the neighboring grids of popped grid (or call it "parent grid")
            for (int i = -1; i <= 1; ++i){
                for (int j = -1; j <= 1; ++j){
                    // 3.1.1 Continue if the checked grid is the popped grid itself
                    if (i == 0 && j == 0)
                        continue;
                    // 3.1.2 Update checked grid indexes
                    thisGrid.cubeX = fromGrid.cubeX;
                    thisGrid.cubeY = fromGrid.cubeY;
                    thisGrid.gridX = fromGrid.gridX + i;
                    thisGrid.gridY = fromGrid.gridY + j;
                    // 3.1.3 If the checked grid is in another sub-map, update it's indexes
                    if(thisGrid.gridX < 0){ --thisGrid.cubeX; thisGrid.gridX = mapCubeArrayLength - 1;
                    }else if(thisGrid.gridX >= mapCubeArrayLength){ ++thisGrid.cubeX; thisGrid.gridX = 0;}

                    if(thisGrid.gridY < 0){ --thisGrid.cubeY; thisGrid.gridY = mapCubeArrayLength - 1;
                    }else if(thisGrid.gridY >= mapCubeArrayLength){ ++thisGrid.cubeY; thisGrid.gridY = 0;}
                    // 3.1.4 If the sub-map that the checked grid belongs to is empty, continue
                    thisSubMapInd = mapArrayInd[thisGrid.cubeX][thisGrid.cubeY];
                    if (thisSubMapInd == -1)
                        continue;
                    // 3.1.5 If the checked grid is outside the boundary of local occupancy grid map, continue
                    thisGridinMapX = thisGrid.cubeX * mapCubeArrayLength + thisGrid.gridX;
                    thisGridinMapY = thisGrid.cubeY * mapCubeArrayLength + thisGrid.gridY;
                    if (abs(thisGridinMapX - robotGridinMapX) >= localMapArrayLength / 2 ||
                        abs(thisGridinMapY - robotGridinMapY) >= localMapArrayLength / 2)
                        continue;
                    // 3.1.6 If the checked grid has no height information
                    if (mapArray[thisSubMapInd].subMap[thisGrid.gridX][thisGrid.gridY].cells.size() == 0)
                        continue;
                    // 3.1.7 Convert index from 2D to 1D
                    mapIndX = (thisGridinMapX - robotGridinMapX) + localMapGridCenterX;
                    mapIndY = (thisGridinMapY - robotGridinMapY) + localMapGridCenterY;
                    index = mapIndX + mapIndY * occupancyMap2DHeight.occupancy.info.width;
                    // 3.1.8 Only proceed if the grid of local occupancy grid map hasn't been updated yet
                    if (occupancyMap2DHeight.occupancy.data[index] != -1)
                        continue;
                    // 3.1.9 Update the grid occupancy of this local occupancy grid map if the height difference is smaller than a threshold
                    //      this prevent expanding grids that belong to another floor
                    for (int heightCount = 0; heightCount < mapArray[thisSubMapInd].subMap[thisGrid.gridX][thisGrid.gridY].cells.size(); ++heightCount){
                        thisHeight = mapArray[thisSubMapInd].subMap[thisGrid.gridX][thisGrid.gridY].cells[heightCount].height;
                        if (abs(fromGrid.height - thisHeight) <= 0.25
                            && (abs(robotPoint.z - thisHeight) < 2 || multiLayerMappingFlag == false)){

                            occupancyMap2DHeight.occupancy.data[index] = mapArray[thisSubMapInd].subMap[thisGrid.gridX][thisGrid.gridY].cells[heightCount].occupancy == 100 ? 100 : 0;
                            occupancyMap2DHeight.height[index] = thisHeight;

                            thisGrid.height = thisHeight;
                            
                            Queue.push(thisGrid);
                            break;
                        }
                    }
                }
            }
        }
        // 4. Publish customized message that has occupancy info and height info
        pubOccupancyMapLocalHeight.publish(occupancyMap2DHeight);
        // 5. Publish local occupancy grid map
        pubOccupancyMapLocal.publish(occupancyMap2DHeight.occupancy);
    }

    bool getFullIndex(PointType *point, int *cubeX, int *cubeY, int *gridX, int *gridY){

        *cubeX = int((point->x + mapCubeLength/2.0) / mapCubeLength) + rootCubeIndex;
        *cubeY = int((point->y + mapCubeLength/2.0) / mapCubeLength) + rootCubeIndex;

        if (point->x + mapCubeLength/2.0 < 0)  --*cubeX;
        if (point->y + mapCubeLength/2.0 < 0)  --*cubeY;

        if (*cubeX < 0 || *cubeY < 0 || *cubeX >=mapArrayLength || *cubeY >= mapArrayLength)
            return false;

        if (mapArrayInd[*cubeX][*cubeY] == -1)
            return false;

        int thisSubMapInd = mapArrayInd[*cubeX][*cubeY];
        *gridX = int((point->x - mapArray[thisSubMapInd].originX) / mapResolution);
        *gridY = int((point->y - mapArray[thisSubMapInd].originY) / mapResolution);

        if (*gridX < 0 || *gridY < 0 || *gridX >=mapCubeArrayLength || *gridY >= mapCubeArrayLength)
            return false;

        if (mapArray[thisSubMapInd].subMap[*gridX][*gridY].cells.size() == 0)
            return false;

        return true;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////////// Occupancy Map (global) /////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void publishGlobalOccupancyGridMap(){

        if (pubOccupancyMap.getNumSubscribers() == 0)
            return;
        // 1. Initialize global occupancy grid map
        initializeOccupancyMap();

        int thisSubMapInd, indX, indY, index;

        // 2. Update all the elements of global occupancy grid map
        for (vector<childMap>::iterator iter = mapArray.begin(); iter != mapArray.end(); iter++) {
            childMap thisSubMap = *iter;
            // 2.1 if this sub-map is ever created, use it's index to find it in vector mapArray
            thisSubMapInd = thisSubMap.subInd;//mapArrayInd[thisSubMap.indX][thisSubMap.indY];
            // 2.2 Loop through all grids in this sub-map
            for (int cubeI = 0; cubeI < mapCubeArrayLength; ++cubeI){
                for (int cubeJ = 0; cubeJ < mapCubeArrayLength; ++cubeJ){

                    if (thisSubMap.subMap[cubeI][cubeJ].cells.size() == 0)
                        continue;
                    // 2.2.1 Update the grid
                    indX = (mapArray[thisSubMapInd].indX - inflatedMinXCubeInd) * mapCubeArrayLength + cubeI;
                    indY = (mapArray[thisSubMapInd].indY - inflatedMinYCubeInd) * mapCubeArrayLength + cubeJ;
                    index = indX + indY * occupancyMap2D.info.width;
                    occupancyMap2D.data[index] = mapArray[thisSubMapInd].subMap[cubeI][cubeJ].cells[0].occupancy == 100 ? 100 : 0;
                }
            }
        }
        pubOccupancyMap.publish(occupancyMap2D);
    }

    void initializeOccupancyMap(){
        // inflatedMinXCubeInd, inflatedMaxXCubeInd, inflatedMinYCubeInd, inflatedMaxYCubeInd
        occupancyMap2D.header.frame_id = "/map";
        occupancyMap2D.header.stamp = ros::Time::now();
        occupancyMap2D.info.width = (inflatedMaxXCubeInd - inflatedMinXCubeInd + 1) * mapCubeArrayLength;
        occupancyMap2D.info.height = (inflatedMaxYCubeInd - inflatedMinYCubeInd + 1) * mapCubeArrayLength;
        occupancyMap2D.info.resolution = mapResolution;
        occupancyMap2D.info.origin.position.x = (inflatedMinXCubeInd - rootCubeIndex) * mapCubeLength - mapCubeLength/2.0;
        occupancyMap2D.info.origin.position.y = (inflatedMinYCubeInd - rootCubeIndex) * mapCubeLength - mapCubeLength/2.0;
        occupancyMap2D.info.origin.position.z = robotPoint.z + 8;
        occupancyMap2D.info.origin.orientation.x = 0.0;
        occupancyMap2D.info.origin.orientation.y = 0.0;
        occupancyMap2D.info.origin.orientation.z = 0.0;
        occupancyMap2D.info.origin.orientation.w = 1.0;
        occupancyMap2D.data.assign(occupancyMap2D.info.width * occupancyMap2D.info.height, -1);  // Fill with "unknown" occupancy.
    }

    void getRobotPosition(){
        try{listener.lookupTransform("map","base_link", ros::Time(0), transform); } 
        catch (tf::TransformException ex){ /*ROS_ERROR("Transfrom Failure.");*/ return; }
        robotPoint.x = transform.getOrigin().x();
        robotPoint.y = transform.getOrigin().y();
        robotPoint.z = transform.getOrigin().z();
    }
};




int main(int argc, char** argv){

    ros::init(argc, argv, "traversability_mapping");
    
    TraversabilityMapping TMAPPING;

    ROS_INFO("\033[1;32m---->\033[0m Traversability %s-layer Map Started.", 
        multiLayerMappingFlag == true ? "\033[1;31mMulti\033[0m" : "\033[1;31mSingle\033[0m");

    ros::spin();
    return 0;
}





